package project_java.tp1.comport;

public interface Estimulo {

}
