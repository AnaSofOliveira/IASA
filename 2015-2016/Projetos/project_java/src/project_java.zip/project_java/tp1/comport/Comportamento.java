package project_java.tp1.comport;

public interface Comportamento {
	
	public Accao activar(Estimulo estimulo);

}
