package project_java.tp1.comport;

public interface Accao {
	
	public void executar();

}
