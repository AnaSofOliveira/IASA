package project_java.tp1.ambiente;

import project_java.tp1.comport.Estimulo;

public enum EventoAmb implements Estimulo{
	SILENCIO, RUIDO, INIMIGO, FUGA, VITORIA, DERROTA, TERMINAR
}
