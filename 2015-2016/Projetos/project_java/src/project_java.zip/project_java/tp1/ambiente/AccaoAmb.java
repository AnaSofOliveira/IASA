package project_java.tp1.ambiente;

import project_java.tp1.comport.Accao;

public enum AccaoAmb implements Accao{
	PATRULHAR, APROXIMAR, AVISAR, DEFENDER, ATACAR, PROCURAR, INICIAR;
	
	public void executar(){
		
	}
}
