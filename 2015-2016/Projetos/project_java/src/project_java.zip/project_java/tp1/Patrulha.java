package project_java.tp1;

import project_java.tp1.jogo.Jogo;

public class Patrulha {

	public static void main(String[] args) {
		
		new Jogo();
		
	}

}
