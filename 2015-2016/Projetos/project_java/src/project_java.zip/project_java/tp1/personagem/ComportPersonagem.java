package project_java.tp1.personagem;

import project_java.tp1.comport.ComportMaqEst;
import project_java.tp1.comport.Estimulo;
import project_java.tp1.maqest.MaquinaEstados;

public class ComportPersonagem extends ComportMaqEst{
	
	protected MaquinaEstados<Estimulo> iniciar(){
		
		
		
	}

}
