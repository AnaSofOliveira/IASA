package project_java.tp2.Puzzle.puzzle;

import project_java.tp2.Puzzle.pee.Solucao;
import project_java.tp2.Puzzle.pee.larg.ProcuraLarg;
import project_java.tp2.Puzzle.pee.mecproc.Percurso;
import project_java.tp2.Puzzle.pee.prof.ProcuraProf;
import project_java.tp2.Puzzle.puzzle.modprob.OperadorMoverPosVazia;
import project_java.tp2.Puzzle.puzzle.modprob.ProblemaPuzzle;
import puzzle.Puzzle;
import puzzle.Puzzle.Movimento;

public class resPuzzle {
	
	public static OperadorMoverPosVazia[] definirOperadores(){
		OperadorMoverPosVazia[] operadores = {  new OperadorMoverPosVazia(Movimento.CIMA), 
												new OperadorMoverPosVazia(Movimento.BAIXO), 
												new OperadorMoverPosVazia(Movimento.ESQ), 
												new OperadorMoverPosVazia(Movimento.DIR)};
		return operadores;
	}

	public static void mostrarConfigura��es(){
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		OperadorMoverPosVazia[] operadores = definirOperadores();
		
		// Configura��es dos Puzzles
		int[][] configInicialA = {{1,2,3},{8,4,5},{6,7,0}};
		int[][] configInicialB = {{8,4,5},{6,1,2},{3,7,0}};
		int[][] configFinal = {{1,2,3},{4,5,6},{7,8,0}};
		
		//Puzzles
		Puzzle puzzleInicialA = new Puzzle(configInicialA);
		Puzzle puzzleInicialB = new Puzzle(configInicialB);
		Puzzle puzzleFinal = new Puzzle(configFinal);
		
		ProblemaPuzzle problemaA = new ProblemaPuzzle(puzzleInicialA, puzzleFinal, operadores);
		ProblemaPuzzle problemaB = new ProblemaPuzzle(puzzleInicialB, puzzleFinal, operadores);
		
		// PROCURA EM LARGURA
		Solucao solucaoALarg = new ProcuraLarg().resolver(problemaA);
		Solucao solucaoBLarg = new ProcuraLarg().resolver(problemaB);
		
		// PROCURA EM PROFUNDIDADE
		Solucao solucaoAProf = new ProcuraProf().resolver(problemaA);
		Solucao solucaoBProf = new ProcuraProf().resolver(problemaB);
		
		
		
		System.out.println("PESQUISA POR LARGURA: \n A");
		System.out.println("Custo da Solu��o (N�mero de Movimentos): \n " + (int)solucaoALarg.getCusto());
//		System.out.println("Complexidade Espacial (N�mero M�ximo de N�s na Fronteira de Explora��o): \n " + solucaoA.);
		System.out.println("Complexidade Temporal (N�mero de N�s Expandidos): \n " + solucaoALarg.getDimensao());
		
		System.out.println("B");
		System.out.println("Custo da Solu��o (N�mero de Movimentos): \n " + (int)solucaoBLarg.getCusto());
//		System.out.println("Complexidade Espacial (N�mero M�ximo de N�s na Fronteira de Explora��o): \n " + solucaoA.);
		System.out.println("Complexidade Temporal (N�mero de N�s Expandidos): \n " + solucaoBLarg.getDimensao());
		
	}
	
	

}
